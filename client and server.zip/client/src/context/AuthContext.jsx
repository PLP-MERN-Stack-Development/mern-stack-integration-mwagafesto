// client/src/context/AuthContext.jsx
import { createContext, useContext, useState } from 'react'
const AuthCtx = createContext(null)
export function AuthProvider({ children }){
  const [token,setToken] = useState(localStorage.getItem('token') || '')
  const [user,setUser] = useState(JSON.parse(localStorage.getItem('user') || 'null'))
  const login = (payload)=>{ setToken(payload.token); setUser(payload.user); localStorage.setItem('token',payload.token); localStorage.setItem('user',JSON.stringify(payload.user)) }
  const logout = ()=>{ setToken(''); setUser(null); localStorage.removeItem('token'); localStorage.removeItem('user') }
  return <AuthCtx.Provider value={{ token, user, login, logout }}>{children}</AuthCtx.Provider>
}
export function useAuth(){ const ctx = useContext(AuthCtx); if(!ctx) throw new Error('useAuth must be used within AuthProvider'); return ctx }
