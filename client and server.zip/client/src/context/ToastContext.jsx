// client/src/context/ToastContext.jsx
import { createContext, useContext, useState, useCallback } from 'react'

const ToastCtx = createContext(null)

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([])
  const push = useCallback((text, kind='info') => {
    const id = Math.random().toString(36).slice(2)
    setToasts(t => [...t, { id, text, kind }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 3000)
  }, [])
  const value = { push }
  return (
    <ToastCtx.Provider value={value}>
      {children}
      <div style={{position:'fixed', right:16, bottom:16, display:'grid', gap:8, zIndex:9999}}>
        {toasts.map(t => (
          <div key={t.id} className="card" style={{borderColor: t.kind==='error' ? '#ef4444' : '#3b82f6'}}>
            {t.text}
          </div>
        ))}
      </div>
    </ToastCtx.Provider>
  )
}

export function useToast(){
  const ctx = useContext(ToastCtx)
  if(!ctx) throw new Error('useToast must be used within ToastProvider')
  return ctx
}
