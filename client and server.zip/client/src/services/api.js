// client/src/services/api.js
const BASE = import.meta.env.VITE_API_BASE_URL || 'http://localhost:4000';
function headers(token, isForm=false){ const h={}; if(!isForm) h['Content-Type']='application/json'; if(token) h['Authorization']=`Bearer ${token}`; return h }
export async function apiGet(path, token){ const res=await fetch(`${BASE}${path}`,{headers:headers(token)}); if(!res.ok) throw new Error(`HTTP ${res.status}`); return res.json() }
export async function apiPost(path, data, token, isForm=false){ const res=await fetch(`${BASE}${path}`,{method:'POST', headers:headers(token,isForm), body:isForm?data:JSON.stringify(data)}); if(!res.ok) throw new Error(`HTTP ${res.status}`); return res.json() }
export async function apiPut(path, data, token, isForm=false){ const res=await fetch(`${BASE}${path}`,{method:'PUT', headers:headers(token,isForm), body:isForm?data:JSON.stringify(data)}); if(!res.ok) throw new Error(`HTTP ${res.status}`); return res.json() }
export async function apiDelete(path, token){ const res=await fetch(`${BASE}${path}`,{method:'DELETE', headers:headers(token)}); if(!res.ok) throw new Error(`HTTP ${res.status}`); return true }
