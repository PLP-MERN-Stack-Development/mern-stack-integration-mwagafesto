// client/src/App.jsx
import { Routes, Route, Link, NavLink, useNavigate, Navigate } from 'react-router-dom'
import Home from './pages/Home.jsx'
import Login from './pages/Login.jsx'
import Register from './pages/Register.jsx'
import NewPost from './pages/NewPost.jsx'
import PostDetails from './pages/PostDetails.jsx'
import { useAuth } from './context/AuthContext.jsx'

function RequireAuth({ children, user }){
  if (!user) return <Navigate to="/login" replace />
  return children
}

export default function App(){
  const { user, logout } = useAuth()
  const nav = useNavigate()
  return (
    <div>
      <nav className="nav">
        <Link to="/" className="brand">MERN Blog</Link>
        <NavLink to="/" end>Home</NavLink>
        {user && <NavLink to="/new">New Post</NavLink>}
        <span style={{marginLeft:'auto'}}/>
        {user ? (<><span>Hi, {user.name}</span><button className="btn" onClick={()=>{logout(); nav('/')}}>Logout</button></>)
               : (<><NavLink to="/login">Login</NavLink><NavLink to="/register">Register</NavLink></>)}
      </nav>
      <div className="container">
        <Routes>
          <Route path="/" element={<Home/>}/>
          <Route path="/login" element={<Login/>}/>
          <Route path="/register" element={<Register/>}/>
          <Route path="/new" element={<RequireAuth user={user}><NewPost/></RequireAuth>}/>
          <Route path="/post/:id" element={<PostDetails/>}/>
        </Routes>
      </div>
    </div>
  )
}
