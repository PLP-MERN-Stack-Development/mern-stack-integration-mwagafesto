// client/src/pages/NewPost.jsx
import { useState } from 'react'
import { useAuth } from '../context/AuthContext.jsx'
import { apiPost } from '../services/api.js'
import { useNavigate } from 'react-router-dom'
import { useToast } from '../context/ToastContext.jsx'
export default function NewPost(){
  const { push } = useToast()
  const { token } = useAuth()
  const nav = useNavigate()
  const [title,setTitle] = useState('')
  const [content,setContent] = useState('')
  const [cover,setCover] = useState(null)
  const [error,setError] = useState('')
  const submit = async (e)=>{ e.preventDefault(); try{ const fd=new FormData(); fd.append('title',title); fd.append('content',content); if(cover) fd.append('cover',cover); await apiPost('/api/posts', fd, token, true) }catch(e){ setError('Create failed'); return } nav('/') }
  return (<form className="card" onSubmit={submit}><h1>New Post</h1>{error && <div style={{color:'#fda4af'}}>{error}</div>}<label>Title</label><input className="input" value={title} onChange={e=>setTitle(e.target.value)} required/><label>Content</label><textarea className="input" rows="8" value={content} onChange={e=>setContent(e.target.value)} required/><label>Cover Image (optional)</label><input className="input" type="file" accept="image/*" onChange={e=>setCover(e.target.files[0])}/><button className="btn" style={{marginTop:12}}>Publish</button></form>)}
