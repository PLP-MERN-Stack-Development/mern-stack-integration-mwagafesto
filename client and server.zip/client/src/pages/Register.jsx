// client/src/pages/Register.jsx
import { useState } from 'react'
import { apiPost } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import { useNavigate } from 'react-router-dom'
export default function Register(){
  const [name,setName] = useState('')
  const [email,setEmail] = useState('')
  const [password,setPassword] = useState('')
  const [error,setError] = useState('')
  const { login } = useAuth()
  const nav = useNavigate()
  const submit = async (e)=>{ e.preventDefault(); setError(''); try{ const res = await apiPost('/api/auth/register', { name, email, password }); login(res); nav('/') }catch(e){ setError('Registration failed') } }
  return (<form className="card" onSubmit={submit}><h1>Register</h1>{error && <div style={{color:'#fda4af'}}>{error}</div>}<label>Name</label><input className="input" value={name} onChange={e=>setName(e.target.value)} placeholder="Your name"/><label>Email</label><input className="input" value={email} onChange={e=>setEmail(e.target.value)} placeholder="you@example.com"/><label>Password</label><input className="input" type="password" value={password} onChange={e=>setPassword(e.target.value)} placeholder="Min 6 chars"/><button className="btn" style={{marginTop:12}}>Create account</button></form>)}
