// client/src/pages/Home.jsx
import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { apiGet } from '../services/api.js'
import { useToast } from '../context/ToastContext.jsx'

export default function Home(){
  const [data,setData] = useState({ items:[], total:0, page:1, pages:1 })
  const [q,setQ] = useState('')
  const [page,setPage] = useState(1)
  const limit = 9
  const { push } = useToast()

  useEffect(()=>{
    (async()=>{
      try {
        const res = await apiGet(`/api/posts?q=${encodeURIComponent(q)}&page=${page}&limit=${limit}`)
        setData(res)
      } catch (e) {
        push('Failed to load posts', 'error')
      }
    })()
  },[q, page])

  return (
    <div className="grid" style={{gap:16}}>
      <div className="card">
        <input className="input" placeholder="Search posts..." value={q} onChange={e=>{setQ(e.target.value); setPage(1)}}/>
      </div>

      <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
        <div>Page {data.page} of {data.pages} • {data.total} posts</div>
        <div style={{display:'flex', gap:8}}>
          <button className="btn" disabled={page<=1} onClick={()=>setPage(p=>p-1)}>Prev</button>
          <button className="btn" disabled={page>=data.pages} onClick={()=>setPage(p=>p+1)}>Next</button>
        </div>
      </div>

      <div className="grid grid-3">
        {data.items.map(p=> (
          <article key={p._id} className="card">
            {p.coverImage && <img alt="" src={p.coverImage} style={{width:'100%', borderRadius:8, marginBottom:8}}/>}
            <h2 style={{fontSize:18, fontWeight:700}}>{p.title}</h2>
            <p style={{opacity:.8}}>{p.content.slice(0,140)}{p.content.length>140?'...':''}</p>
            <div style={{display:'flex', justifyContent:'space-between', marginTop:8, fontSize:12, opacity:.8}}>
              <span>by {p.author?.name||'Unknown'}</span>
              <Link to={`/post/${p._id}`}>Read</Link>
            </div>
          </article>
        ))}
      </div>
    </div>
  )
}
