// client/src/pages/PostDetails.jsx
import { useEffect, useState } from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { apiGet, apiPost, apiPut, apiDelete } from '../services/api.js'
import { useAuth } from '../context/AuthContext.jsx'
import { useToast } from '../context/ToastContext.jsx'

export default function PostDetails(){
  const { id } = useParams()
  const nav = useNavigate()
  const [post,setPost] = useState(null)
  const [comments,setComments] = useState([])
  const [body,setBody] = useState('')
  const [editing, setEditing] = useState(false)
  const [title, setTitle] = useState('')
  const [content, setContent] = useState('')
  const [cover, setCover] = useState(null)

  const { token, user } = useAuth()
  const { push } = useToast()

  const isOwner = user && post && (post.author?._id === user.id || post.author === user.id)

  useEffect(()=>{
    (async()=>{
      const p = await apiGet(`/api/posts/${id}`); setPost(p); setTitle(p.title); setContent(p.content)
      const cs = await apiGet(`/api/comments?postId=${id}`); setComments(cs)
    })()
  },[id])

  const add = async (e)=>{
    e.preventDefault()
    if(!token) { push('Login to comment', 'error'); return }
    const c = await apiPost('/api/comments', { postId:id, body }, token)
    setComments([c, ...comments]); setBody('')
  }

  const save = async (e) => {
    e.preventDefault()
    if(!token) return
    const fd = new FormData()
    fd.append('title', title)
    fd.append('content', content)
    if (cover) fd.append('cover', cover)
    const updated = await apiPut(`/api/posts/${id}`, fd, token, true)
    setPost(updated); setEditing(false); setCover(null)
    push('Post updated')
  }

  const remove = async () => {
    if (!token) return
    if (!confirm('Delete this post?')) return
    await apiDelete(`/api/posts/${id}`, token)
    push('Post deleted')
    nav('/')
  }

  if(!post) return <div>Loading…</div>

  return (
    <div className="grid" style={{gap:16}}>
      <article className="card">
        {post.coverImage && <img alt="" src={post.coverImage} style={{width:'100%', borderRadius:8, marginBottom:8}}/>}

        {editing ? (
          <form onSubmit={save}>
            <input className="input" value={title} onChange={e=>setTitle(e.target.value)} required/>
            <textarea className="input" rows="8" value={content} onChange={e=>setContent(e.target.value)} required/>
            <input className="input" type="file" accept="image/*" onChange={e=>setCover(e.target.files[0])}/>
            <div style={{display:'flex', gap:8, marginTop:8}}>
              <button className="btn" type="submit">Save</button>
              <button className="btn" type="button" onClick={()=>setEditing(false)}>Cancel</button>
            </div>
          </form>
        ) : (
          <>
            <h1 style={{fontSize:26, fontWeight:800}}>{post.title}</h1>
            <div style={{opacity:.7, marginBottom:8}}>by {post.author?.name||'Unknown'}</div>
            <p style={{whiteSpace:'pre-wrap'}}>{post.content}</p>
            {isOwner && (
              <div style={{display:'flex', gap:8, marginTop:12}}>
                <button className="btn" onClick={()=>setEditing(true)}>Edit</button>
                <button className="btn" onClick={remove}>Delete</button>
              </div>
            )}
          </>
        )}
      </article>

      <section className="card">
        <h2>Comments</h2>
        {token ? (
          <form onSubmit={add} style={{marginBottom:12}}>
            <textarea className="input" rows="3" placeholder="Write a comment…" value={body} onChange={e=>setBody(e.target.value)} required/>
            <button className="btn" style={{marginTop:8}}>Post comment</button>
          </form>
        ) : (
          <div style={{opacity:.8}}>Login to comment.</div>
        )}
        <div className="grid">
          {comments.map(c => (
            <div key={c._id} className="card">
              <div style={{fontSize:14, opacity:.8}}>by {c.author?.name||'Unknown'}</div>
              <div>{c.body}</div>
            </div>
          ))}
        </div>
      </section>
    </div>
  )
}
