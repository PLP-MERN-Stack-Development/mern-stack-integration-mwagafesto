// server/controllers/comment.controller.js
import { Comment } from '../models/Comment.js';

export async function listComments(req, res) {
  try {
    const { postId } = req.query;
    if (!postId) return res.status(400).json({ message: 'postId required' });
    const items = await Comment.find({ post: postId }).sort({ createdAt: -1 }).populate('author', 'name').lean();
    res.json(items);
  } catch {
    res.status(500).json({ message: 'Failed to list comments' });
  }
}

export async function createComment(req, res) {
  try {
    const { postId, body } = req.body;
    if (!postId || !body) return res.status(400).json({ message: 'postId and body required' });
    const comment = await Comment.create({ post: postId, body, author: req.user.id });
    res.status(201).json(comment);
  } catch {
    res.status(400).json({ message: 'Create failed' });
  }
}
