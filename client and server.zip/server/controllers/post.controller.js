// server/controllers/post.controller.js
import { Post } from '../models/Post.js';

function fileToUrl(file) {
  if (!file) return '';
  // Cloudinary: file.path is already a fully qualified URL
  if (file.path && file.path.startsWith('http')) return file.path;
  // Disk: build local URL path
  return `/uploads/${file.filename}`;
}

export async function listPosts(req, res) {
  try {
    const { q, page = 1, limit = 9 } = req.query;
    const filter = q ? { $text: { $search: String(q) } } : {};
    const skip = (Number(page) - 1) * Number(limit);
    const [items, total] = await Promise.all([
      Post.find(filter).sort({ createdAt: -1 }).skip(skip).limit(Number(limit)).populate('author', 'name').lean(),
      Post.countDocuments(filter)
    ]);
    res.json({ total, page: Number(page), pages: Math.ceil(total / Number(limit)) || 1, items });
  } catch (e) {
    res.status(500).json({ message: 'Failed to list posts' });
  }
}

export async function getPost(req, res) {
  try {
    const post = await Post.findById(req.params.id).populate('author', 'name').lean();
    if (!post) return res.status(404).json({ message: 'Not found' });
    res.json(post);
  } catch {
    res.status(404).json({ message: 'Not found' });
  }
}

export async function createPost(req, res) {
  try {
    const { title, content } = req.body;
    const coverImage = fileToUrl(req.file);
    const post = await Post.create({ title, content, coverImage, author: req.user.id });
    res.status(201).json(post);
  } catch (e) {
    res.status(400).json({ message: 'Create failed' });
  }
}

export async function updatePost(req, res) {
  try {
    const updates = { ...req.body };
    if (req.file) updates.coverImage = fileToUrl(req.file);
    const post = await Post.findOneAndUpdate({ _id: req.params.id, author: req.user.id }, updates, { new: true });
    if (!post) return res.status(404).json({ message: 'Not found or not owner' });
    res.json(post);
  } catch (e) {
    res.status(400).json({ message: 'Update failed' });
  }
}

export async function deletePost(req, res) {
  try {
    const del = await Post.findOneAndDelete({ _id: req.params.id, author: req.user.id });
    if (!del) return res.status(404).json({ message: 'Not found or not owner' });
    res.status(204).send();
  } catch (e) {
    res.status(400).json({ message: 'Delete failed' });
  }
}
