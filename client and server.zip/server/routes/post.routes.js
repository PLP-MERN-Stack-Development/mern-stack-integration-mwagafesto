// server/routes/post.routes.js
import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import { fileURLToPath } from 'url';
import { requireAuth } from '../middleware/auth.js';
import { listPosts, getPost, createPost, updatePost, deletePost } from '../controllers/post.controller.js';
import { configureCloudinaryFromEnv } from '../config/cloudinary.js';
import { CloudinaryStorage } from 'multer-storage-cloudinary';

const router = Router();

// If Cloudinary env vars are present, store uploads there; otherwise use disk
const cloudinary = configureCloudinaryFromEnv();
let upload;
if (cloudinary) {
  const storage = new CloudinaryStorage({
    cloudinary,
    params: async (req, file) => ({
      folder: 'mern-blog',
      resource_type: 'image',
      format: undefined // keep original
    })
  });
  upload = multer({ storage });
} else {
  const __filename = fileURLToPath(import.meta.url);
  const __dirname = path.dirname(__filename);
  const storage = multer.diskStorage({
    destination: (req, file, cb) => cb(null, path.join(__dirname, '../uploads')),
    filename: (req, file, cb) => {
      const unique = Date.now() + '-' + Math.round(Math.random()*1e9);
      const ext = path.extname(file.originalname);
      cb(null, unique + ext);
    }
  });
  upload = multer({ storage });
}

router.get('/', listPosts);
router.get('/:id', getPost);
router.post('/', requireAuth, upload.single('cover'), createPost);
router.put('/:id', requireAuth, upload.single('cover'), updatePost);
router.delete('/:id', requireAuth, deletePost);

export default router;
