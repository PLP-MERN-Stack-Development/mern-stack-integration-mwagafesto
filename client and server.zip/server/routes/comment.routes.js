// server/routes/comment.routes.js
import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { listComments, createComment } from '../controllers/comment.controller.js';
const router = Router();
router.get('/', listComments);
router.post('/', requireAuth, createComment);
export default router;
